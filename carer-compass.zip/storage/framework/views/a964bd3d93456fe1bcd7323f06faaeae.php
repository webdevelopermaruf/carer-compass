<?php $__env->startSection('page'); ?>
    <div class="banner-container-comming-soon" style="padding-bottom: 20px">
        <div class="container">
            <div class="row">
                <form action="/search" method="GET" class="input-group mb-3 input-field-form">
                    <input style="text-transform: uppercase" type="text" class="form-control input-form-input"
                           value="<?php echo e(request()->query('q')); ?>"  maxlength="3"
                           placeholder="Enter your post Code..." name="q" required>
                    <div class="input-group-append form-button">
                        <button type="submit" class="btn btn-form-section">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-end mr-5">
        <?php echo e($carers->appends(request()->query())->links()); ?>

    </div>
    <div class="profile-container" style="margin-bottom: 137px">
        <?php $__empty_1 = true; $__currentLoopData = $carers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="profile-card" style="max-width: 350px;">
            <div class="profile-image">
                <div class="avatar"><?php echo e($carer->name[0]); ?></div>
            </div>
            <div class="profile-content">
                <h3 class="profile-name"><?php echo e($carer->name); ?> <i class="fas fa-check-circle verified"></i></h3>
                <p class="location"><?php echo e($carer->location); ?></p>
                <p class="response-time">⚡ Service Areas - <?php echo e(implode(', ', json_decode($carer->service_area))); ?> </p>
                <p class="description">
                    <?php echo e(substr($carer->about, 0, 100)); ?>...
                </p>
                <div class="icons">
                   <?php echo e($carer->training); ?>

                </div>
                <a href="/profile/<?php echo e($carer->id); ?>">
                    <button  class="custom-btn"><i class="fas fa-book"></i> Read More</button>
                </a>
            </div>

        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2>Sorry ! No Carer Found.</h2>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web Development\Laravel\CarerCompass\resources\views/search.blade.php ENDPATH**/ ?>