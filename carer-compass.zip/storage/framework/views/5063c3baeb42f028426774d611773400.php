<?php $__env->startSection('page'); ?>
    <div class="banner-container-comming-soon" style="padding-bottom:20px;">
        <div class="container">
            <div class="row">
                <form action="/search" method="GET" class="input-group input-field-form">
                    <input style="text-transform: uppercase"  maxlength="3"
                           type="text" class="form-control input-form-input" value=""
                           placeholder="Enter your post Code..." name="q" required="">
                    <div class="input-group-append form-button">
                        <button type="submit" class="btn btn-form-section">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="profile-container">
        <div class="profile-card-details" style="width: 100%">
            <div class="profile-header">
                <div class="profile-info">
                   <div class="d-flex">
                       <div class="avatar mr-3"><?php echo e($carer->name[0]); ?></div>
                       <h2><?php echo e($carer->name); ?></h2>
                   </div>
                    <p>Located in <?php echo e($carer->location); ?></p>
                    <p class="response-time">⚡ Service Areas - <?php echo e(implode(', ', json_decode($carer->service_area))); ?> </p>
                </div>
            </div>
            <div class="profile-actions">
                <a href="https://wa.me/<?php echo e($carer->whatsapp); ?>" class="btn btn-lg btn-success">💬 Chat on WhatsApp</a>
                <a href="tel:<?php echo e($carer->phone); ?>" class="btn btn-lg btn-warning">📲 Mobile</a>
                <a href="mailto:<?php echo e($carer->email); ?>" class="btn btn-dark btn-lg">✉ Email</a>
            </div>

            <div class="profile-summary">
                <h3 class="text-center pt-5" style="color: #3b579d">About Me</h3>
                <p class="px-5 py-3" style="font-size: 16px; color: rgb(89, 88, 88);">
                    <?php echo $carer->about; ?>

                </p>
            </div>
            <div class="profile-summary">
                <h3 class="text-center" style="color: #3b579d">My Experience</h3>
                <p style="font-size: 16px; color: rgb(89, 88, 88);">
                I have over <?php echo e($carer->experience); ?>+ experience on this.
                    My Training & Qualities are:
                    <li><?php echo e($carer->training); ?></li>
                </p>
            </div>
            <div class="container" style="padding-bottom: 50px; padding-top:20px;">
                <h3 class="text-center mb-4" style="color: #3b579d">📝 Reviews</h3>

                
                <?php if(auth()->guard('parent')->check()): ?>
                    <div class="mb-4 text-left">
                        <div class="card-header bg-primary text-white">Leave a Review</div>
                        <div class="card-body">
                            <form action="/leave-review/<?php echo e($carer->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="rating">Rating (1-5)</label>
                                    <select class="form-control" name="rating" required>
                                        <option value="">Select Rating</option>
                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?> Star<?php echo e($i > 1 ? 's' : ''); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="form-group mt-3">
                                    <label for="comment">Comment</label>
                                    <textarea name="comment" rows="4" class="form-control" placeholder="Write your review..." required></textarea>
                                </div>
                                <button type="submit" class="btn btn-success mt-3">Submit Review</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(!auth()->guard('parent')->user()): ?>
                    <h4>If you want to leave review please <a style="font-size: 22px" href="/register-as-parent">Register as parent</a></h4>
                <?php endif; ?>

                
                <div>
                    <div class="card-header bg-secondary text-white">Recent Reviews</div>
                    <div class="card-body text-left">
                        <?php if($carer->review): ?>
                            <?php $__currentLoopData = $carer->review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border-bottom mb-3 pb-2">
                                    <strong><?php echo e($review->parent->name ?? 'Anonymous'); ?></strong>
                                    <span class="text-warning">
                            <?php for($i = 0; $i < $review->rating; $i++): ?> ★ <?php endfor; ?>
                        </span>
                                    <p class="mb-1"><?php echo e($review->review_body); ?></p>
                                    <small class="text-muted"><?php echo e($review->created_at->diffForHumans()); ?></small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted">No reviews yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web Development\Laravel\CarerCompass\resources\views/carer/profile.blade.php ENDPATH**/ ?>