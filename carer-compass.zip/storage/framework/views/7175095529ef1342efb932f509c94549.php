<?php $__env->startSection('page'); ?>

    <section class="login-form d-flex align-items-center" style="padding-bottom: 150px">
        <div class="container">
            <div class="login-form-title text-center">
                <h2>Login</h2>
            </div>
            <div class="login-form-box">
                <div class="login-card">
                    <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong> Your Credentials was incorrect.</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                    <form action="/login" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <input type="radio" id="parent" name="user" value="parent" checked>
                            <label for="parent" class="mr-2">Parent</label>
                            <input type="radio" id="carer" name="user" value="carer">
                            <label for="carer" class="mr-2">Carer</label>
                            <input type="radio" id="admin" name="user" value="admin">
                            <label for="admin" class="mr-2">Administrator</label>
                        </div>
                        <div class="form-group">
                            <input class="input-field form-control" type="email"  placeholder="Email" required name="email">
                        </div>
                        <div class="form-group">
                            <input class="input-field form-control" type="password" placeholder="Password" required name="password">
                        </div>
                        <div class="form-check">
                            <input type="checkbox" name="gdpr_consent" required class="form-check-input" id="gdprCheck">
                            <label class="form-check-label" for="gdprCheck">
                                I agree to the processing of my data in accordance with the privacy policy.
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary hover-effect">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web Development\Laravel\CarerCompass\resources\views/login.blade.php ENDPATH**/ ?>