<?php $__env->startSection('css'); ?>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: Arial, sans-serif;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
    <div style="margin-bottom: 150px;">
        <h1 class="my-3 text-center">Carers List</h1>
        <table class="container">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Location</th>
                <th>WhatsApp</th>
                <th>Experience</th>
                <th>Service Area</th>
                <th>Training</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($carer->name); ?></td>
                    <td><?php echo e($carer->email); ?></td>
                    <td><?php echo e($carer->phone); ?></td>
                    <td><?php echo e($carer->location); ?></td>
                    <td><?php echo e($carer->whatsapp); ?></td>
                    <td><?php echo e($carer->experience); ?></td>
                    <td><?php echo e(implode(',', json_decode($carer->service_area))); ?></td>
                    <td><?php echo e($carer->training); ?></td>
                    <?php if($carer->status === 0): ?>
                        <td class="text-primary">Pending</td>
                    <?php elseif($carer->status === 1): ?>
                        <td class="text-success">Approved</td>
                    <?php else: ?>
                        <td class="text-danger">Canceled</td>
                    <?php endif; ?>
                    <td>
                        <?php if($carer->status === 0): ?>
                            <a href="/update_status?status=approved&&carer=<?php echo e($carer->id); ?>" class="btn btn-sm btn-success">Approve</a>
                            <a href="/update_status?status=rejected&&carer=<?php echo e($carer->id); ?>" class="btn btn-sm btn-danger mt-2">Cancel</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Web Development\Laravel\CarerCompass\resources\views/dashboard.blade.php ENDPATH**/ ?>